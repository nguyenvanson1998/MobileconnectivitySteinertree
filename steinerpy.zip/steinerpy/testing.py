from steinerpy.library.graphs.graph import GraphFactory
from steinerpy.context import Context
import logging
logging.getLogger('file_handler').addHandler(logging.NullHandler())
logging.getLogger('file_handler').propagate = False
import itertools



grid_size = 3   # grid fineness
terminals = [(-7,-13), (2, -10), (-8,-8)]
# Create context
minX = min(terminals, key = lambda x: x[0])[0]
maxX = ((max(terminals, key = lambda x: x[0])[0] - minX)//grid_size +1)*grid_size + minX
minY = min(terminals, key = lambda x: x[1])[1]
maxY = ((max(terminals, key = lambda x: x[1])[1] - minY)//grid_size +1)*grid_size + minY

print("MinX = {0} , MaxX = {1}".format(minX,maxX))
# Spec out our `SquareGrid` type graph object using `GraphFactory`
grid = None         # pre-existing 2d numpy array, where 1=obstacle
grid_dim = [minX, maxX, minY, maxY]
n_type = 4          # either 8 or 4 cell neighbors

# Create a squareGrid using GraphFactory
graph = GraphFactory.create_graph("SquareGrid", grid=grid, grid_dim=grid_dim, grid_size=grid_size, n_type= n_type)  



modified_ter = []
# format the terminals
for ter in terminals:
    x = min(((ter[0] - minX)//grid_size +1)*grid_size + minX, maxX)
    y = min(((ter[1] - minY)//grid_size +1)*grid_size + minY, maxY)
    modified_ter.append((x,y))

print(modified_ter)




context = Context(graph, modified_ter)

# run and store results for S star heuristic search
context.run('S*-MM')
results = context.return_solutions()
res = list(set(itertools.chain.from_iterable(results['path'])))
print(res)