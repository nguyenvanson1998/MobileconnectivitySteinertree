steinerpy.abstract\_algo
========================

.. automodule:: steinerpy.abstract_algo

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
      :nosignatures:
   
      AbstractAlgorithm
   
   

   
   
   




