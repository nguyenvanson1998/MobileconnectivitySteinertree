steinerpy.context.Context
=========================

.. currentmodule:: steinerpy.context

.. autoclass:: Context
   :members:
   :show-inheritance:
   :inherited-members:
   :special-members: __call__, __add__, __mul__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Context.return_solutions
      ~Context.run
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Context.strategy
   
   
