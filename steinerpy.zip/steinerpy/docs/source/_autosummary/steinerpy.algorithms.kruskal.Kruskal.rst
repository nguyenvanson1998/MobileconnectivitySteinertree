steinerpy.algorithms.kruskal.Kruskal
====================================

.. currentmodule:: steinerpy.algorithms.kruskal

.. autoclass:: Kruskal
   :members:
   :show-inheritance:
   :inherited-members:
   :special-members: __call__, __add__, __mul__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Kruskal.return_solutions
      ~Kruskal.run_algorithm
   
   

   
   
   
