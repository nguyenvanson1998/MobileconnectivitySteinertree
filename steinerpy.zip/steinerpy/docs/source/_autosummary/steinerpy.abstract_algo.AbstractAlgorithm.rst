steinerpy.abstract\_algo.AbstractAlgorithm
==========================================

.. currentmodule:: steinerpy.abstract_algo

.. autoclass:: AbstractAlgorithm
   :members:
   :show-inheritance:
   :inherited-members:
   :special-members: __call__, __add__, __mul__

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~AbstractAlgorithm.return_solutions
      ~AbstractAlgorithm.run_algorithm
   
   

   
   
   
