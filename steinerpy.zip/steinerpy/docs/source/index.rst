.. SteinerTreeAccelerated documentation master file, created by
   sphinx-quickstart on Wed Jul 29 17:10:25 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SteinerTreeAccelerated's documentation!
==================================================
.. toctree::
   
   readme_link
   todo_link

.. autosummary::
   :toctree: _autosummary
   :caption: API Reference
   :template: custom-module-template.rst
   :recursive:

   steinerpy
