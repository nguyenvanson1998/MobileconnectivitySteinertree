# TODO List
## Roadmap
 - Refactor the code like crazy
 - Finish documenting modules and provide more examples of how to use library

