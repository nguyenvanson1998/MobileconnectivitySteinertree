# Notes
- Grid maps obtained from [link](https://movingai.com/benchmarks/mapf/index.html)

# Issues
- room-64-64-16.map has a disconnected room, so it required some modifications. Specifically, room (2,0) (assuming (1,1) is the top-left) has its eastern wall removed by one block
